// Copyright 2025 Władysław Witkowski. All Rights Reserved.

#include "GoogleAdMobGameInstance.h"
#include "GoogleAdMob.h"
#include "GoogleAdMobAdState.h"
#include "GoogleAdMobAppOpenAd.h"
#include "GoogleAdMobResponseInfo.h"
#include "GoogleAdMobAdError.h"
#include "GoogleAdMobAdValue.h"
#include "GoogleAdMobBannerAd.h"
#include "GoogleAdMobInterstitialAd.h"
#include "GoogleAdMobRewardedAd.h"
#include "GoogleAdMobRewardedInterstitialAd.h"
#include "GoogleAdMobMenu.h"
#ifdef GOOGLE_UMP
#include "GoogleUMP.h"
#endif

void UGoogleAdMobGameInstance::Init()
{
	Super::Init();

	UClass* WBPClass = LoadObject<UClass>(
		nullptr,
		TEXT("/Game/WBP_GoogleAdMobMenu.WBP_GoogleAdMobMenu_C")
	);
	GoogleAdMobMenu = CreateWidget<UGoogleAdMobMenu>(this, WBPClass);
	GoogleAdMobMenu->GameInstance = this;

#ifdef GOOGLE_UMP
	TSharedRef<bool> bInitFlag = MakeShared<bool>(false);
	
	UGoogleUMP::OnRequestConsentInfoUpdateSuccess.AddLambda([this, bInitFlag]
		{
			GoogleAdMobMenu->AddLogEntry(TEXT("CONSENT INFO UPDATED SUCCESSFULLY"));
			GoogleAdMobMenu->SetPrivacyOptionsButtonVisibility();

			UGoogleUMP::OnConsentFormDismissed.AddLambda([this, bInitFlag]
				{
					GoogleAdMobMenu->AddLogEntry(TEXT("CONSENT FORM DISMISSED"));
					if (UGoogleUMP::CanRequestAds())
					{
						if (!*bInitFlag)
						{
							*bInitFlag = true;
							GoogleAdMobMenu->AddLogEntry(TEXT(
								"UGoogleUMP::CanRequestAds() returned true. Initializing Google AdMob SDK..."));
							UGoogleAdMob::Initialize();
						}
					}
					else
					{
						GoogleAdMobMenu->AddLogEntry(TEXT(
							"UGoogleUMP::CanRequestAds() returned false. Cannot initialize Google AdMob SDK until consent from user is obtained"));
					}
				}
			);

			UGoogleUMP::OnConsentFormDismissedWithError.AddLambda([this]
			(const int32 ErrorCode, const FString& ErrorMessage)
				{
					GoogleAdMobMenu->AddLogEntry(TEXT("CONSENT FORM DISMISSED WITH ERROR:\n"), ErrorCode, ErrorMessage);
				}
			);

			UGoogleUMP::LoadAndShowConsentFormIfRequired();
		}
	);
	UGoogleUMP::OnRequestConsentInfoUpdateFailure.AddLambda([this]
	(const int32 ErrorCode, const FString& ErrorMessage)
		{
			GoogleAdMobMenu->AddLogEntry(TEXT("CONSENT INFO UPDATE FAILED WITH ERROR:\n"), ErrorCode, ErrorMessage);
		}
	);
	UGoogleUMP::RequestConsentInfoUpdate();

	if (UGoogleUMP::CanRequestAds() && !*bInitFlag)
	{
		*bInitFlag = true;
		UGoogleAdMob::Initialize();
	}
#else
	UGoogleAdMob::Initialize();
	GoogleAdMobMenu->SetPrivacyOptionsButtonVisibility();
#endif

	ApplicationHasEnteredForegroundDelegate.AddDynamic(this, &UGoogleAdMobGameInstance::ShowAppOpenAd);

	BannerAd = NewObject<UGoogleAdMobBannerAd>(this);
	BannerAd->OnLoaded.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdLoaded);
	BannerAd->OnFailedToLoad.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdFailedToLoad);
	BannerAd->OnClicked.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdClicked);
	BannerAd->OnImpression.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdImpression);
	BannerAd->OnOpened.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdOpened);
	BannerAd->OnPaidEvent.AddUObject(this, &UGoogleAdMobGameInstance::BannerAdPaidEvent);
}

void UGoogleAdMobGameInstance::OnStart()
{
	Super::OnStart();

	GoogleAdMobMenu->AddToViewport();
}

#pragma region APP_OPEN_AD

void UGoogleAdMobGameInstance::LoadAppOpenAd()
{
#ifdef GOOGLE_UMP
	if (!UGoogleUMP::CanRequestAds())
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("UGoogleUMP::CanRequestAds() RETURNED FALSE. DID YOU OBTAIN CONSENT FROM THE USER?"));
		return;
	}
#endif

	UGoogleAdMobAppOpenAd* AppOpenAd = NewObject<UGoogleAdMobAppOpenAd>();

	AppOpenAd->OnLoaded.AddLambda([this](const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("APP OPEN AD LOADED WITH RESPONSE INFO:\n") + ResponseInfo.FullResponse +
			TEXT("\nYOU CAN NOW MINIMIZE THE APP AND RE-OPEN IT AGAIN TO SEE THE AD"));
	});
	AppOpenAd->OnFailedToLoad.AddLambda([this](const FGoogleAdMobAdError& LoadAdError, const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD FAILED TO LOAD WITH ERROR:\n") + LoadAdError.FullError +
			TEXT("\n...AND RESPONSE INFO:\n") + ResponseInfo.FullResponse);
		CleanUpAppOpenAds();
	});
	AppOpenAd->OnClicked.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD CLICKED"));
	});
	AppOpenAd->OnImpression.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD IMPRESSION"));
	});
	AppOpenAd->OnPaidEvent.AddLambda([this](const FGoogleAdMobAdValue& AdValue)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(TEXT(
			"APP OPEN AD PAID WITH AD VALUE:\nVALUE MICROS: %lld\nPRECISION TYPE: %hhd\nDOMAIN (CURRENCY CODE): %s"),
			AdValue.ValueMicros, AdValue.PrecisionType, *AdValue.CurrencyCode));
	});
	AppOpenAd->OnDismissed.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD DISMISSED"));
		CleanUpAppOpenAds();
	});
	AppOpenAd->OnFailedToShow.AddLambda([this](const FGoogleAdMobAdError& AdError)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD FAILED TO SHOW WITH ERROR:\n") + AdError.FullError);
		CleanUpAppOpenAds();
	});
	AppOpenAd->OnShown.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD SHOWN"));
	});

	AppOpenAds.Add(AppOpenAd);

#if PLATFORM_ANDROID
	AppOpenAd->Load(TEXT("ca-app-pub-3940256099942544/9257395921"));
#elif PLATFORM_IOS
	AppOpenAd->Load(TEXT("ca-app-pub-3940256099942544/5575463023"));
#endif

	GoogleAdMobMenu->AddLogEntry(TEXT("LOADING APP OPEN AD..."));
	GoogleAdMobMenu->UpdateAppOpenAdsNumber();
}

void UGoogleAdMobGameInstance::CleanUpAppOpenAds()
{
	AppOpenAds.RemoveAll([this](auto AppOpenAd)
	{
		if (AppOpenAd->GetState() == EGoogleAdMobAdState::Unknown
			|| AppOpenAd->GetState() == EGoogleAdMobAdState::Expired)
			return true;
		return false;
	});
	GoogleAdMobMenu->UpdateAppOpenAdsNumber();
}

void UGoogleAdMobGameInstance::IsAppOpenAdReady()
{
	for (auto AppOpenAd : AppOpenAds)
	{
		if (AppOpenAd->IsReady())
		{
			GoogleAdMobMenu->AddLogEntry(TEXT(
				"APP OPEN AD IS READY TO BE SHOWN. YOU CAN MINIMIZE THE APP AND RE-OPEN IT AGAIN TO SEE THE AD"));
			return;
		}
	}
	GoogleAdMobMenu->AddLogEntry(TEXT("APP OPEN AD IS NOT LOADED OR HAS EXPIRED"));
}

void UGoogleAdMobGameInstance::ShowAppOpenAd()
{
	CleanUpAppOpenAds();
	for (auto AppOpenAd : AppOpenAds)
	{
		if (AppOpenAd->GetState() == EGoogleAdMobAdState::Loaded)
		{
			AppOpenAd->Show();
			return;
		}
	}
}

#pragma endregion

#pragma region BANNER_AD

void UGoogleAdMobGameInstance::LoadBannerAd(EGoogleAdMobBannerSize BannerSize,
	EGoogleAdMobCollapsibleBannerPlacement CollapsibleBannerPlacement) const
{
#ifdef GOOGLE_UMP
	if (!UGoogleUMP::CanRequestAds())
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("UGoogleUMP::CanRequestAds() RETURNED FALSE. DID YOU OBTAIN CONSENT FROM THE USER?"));
		return;
	}
#endif

#if PLATFORM_ANDROID
	if (BannerSize == EGoogleAdMobBannerSize::Adaptive)
	{
		BannerAd->Load(TEXT("ca-app-pub-3940256099942544/9214589741"), BannerSize, CollapsibleBannerPlacement);
	}
	else
	{
		BannerAd->Load(TEXT("ca-app-pub-3940256099942544/6300978111"), BannerSize, CollapsibleBannerPlacement);
	}
#elif PLATFORM_IOS
	if (BannerSize == EGoogleAdMobBannerSize::Adaptive)
	{
		BannerAd->Load(TEXT("ca-app-pub-3940256099942544/2435281174"), BannerSize, CollapsibleBannerPlacement);
	}
	else
	{
		BannerAd->Load(TEXT("ca-app-pub-3940256099942544/2934735716"), BannerSize, CollapsibleBannerPlacement);
	}
#endif

	GoogleAdMobMenu->AddLogEntry(TEXT("LOADING BANNER AD..."));
}

void UGoogleAdMobGameInstance::ShowBannerAd(EGoogleAdMobBannerPosition BannerPosition) const
{
	BannerAd->Show(BannerPosition);
}

void UGoogleAdMobGameInstance::HideBannerAd() const
{
	BannerAd->Hide();
}

void UGoogleAdMobGameInstance::DestroyBannerAd() const
{
	BannerAd->Destroy();
}

void UGoogleAdMobGameInstance::BannerAdLoaded(const FGoogleAdMobResponseInfo& ResponseInfo) const
{
	GoogleAdMobMenu->AddLogEntry(
		TEXT("BANNER AD LOADED WITH RESPONSE INFO:\n") + ResponseInfo.FullResponse);
}

void UGoogleAdMobGameInstance::BannerAdFailedToLoad(const FGoogleAdMobAdError& LoadAdError,
	const FGoogleAdMobResponseInfo& ResponseInfo) const
{
	GoogleAdMobMenu->AddLogEntry(TEXT("BANNER AD FAILED TO LOAD WITH ERROR:\n") + LoadAdError.FullError +
		TEXT("\n...AND RESPONSE INFO:\n") + ResponseInfo.FullResponse);
}

void UGoogleAdMobGameInstance::BannerAdClicked() const
{
	GoogleAdMobMenu->AddLogEntry(TEXT("BANNER AD CLICKED"));
}

void UGoogleAdMobGameInstance::BannerAdImpression() const
{
	GoogleAdMobMenu->AddLogEntry(TEXT("BANNER AD IMPRESSION"));
}

void UGoogleAdMobGameInstance::BannerAdOpened() const
{
	GoogleAdMobMenu->AddLogEntry(TEXT("BANNER AD OPENED"));
}

void UGoogleAdMobGameInstance::BannerAdPaidEvent(const FGoogleAdMobAdValue& AdValue) const
{
	GoogleAdMobMenu->AddLogEntry(FString::Printf(TEXT(
		"APP OPEN AD PAID WITH AD VALUE:\nVALUE MICROS: %lld\nPRECISION TYPE: %hhd\nDOMAIN (CURRENCY CODE): %s"),
		AdValue.ValueMicros, AdValue.PrecisionType, *AdValue.CurrencyCode));
}

#pragma endregion

#pragma region INTERSTITIAL_AD

void UGoogleAdMobGameInstance::LoadInterstitialAd()
{
#ifdef GOOGLE_UMP
	if (!UGoogleUMP::CanRequestAds())
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("UGoogleUMP::CanRequestAds() RETURNED FALSE. DID YOU OBTAIN CONSENT FROM THE USER?"));
		return;
	}
#endif

	UGoogleAdMobInterstitialAd* InterstitialAd = NewObject<UGoogleAdMobInterstitialAd>();

	InterstitialAd->OnLoaded.AddLambda([this](const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("INTERSTITIAL AD LOADED WITH RESPONSE INFO:\n") + ResponseInfo.FullResponse);
	});
	InterstitialAd->OnFailedToLoad.AddLambda([this](const FGoogleAdMobAdError& LoadAdError,
		const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD FAILED TO LOAD WITH ERROR:\n") + LoadAdError.FullError +
			TEXT("\n...AND RESPONSE INFO:\n") + ResponseInfo.FullResponse);
		CleanUpInterstitialAds();
	});
	InterstitialAd->OnClicked.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD CLICKED"));
	});
	InterstitialAd->OnImpression.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD IMPRESSION"));
	});
	InterstitialAd->OnPaidEvent.AddLambda([this](const FGoogleAdMobAdValue& AdValue)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(TEXT(
			"INTERSTITIAL AD PAID WITH AD VALUE:\nVALUE MICROS: %lld\nPRECISION TYPE: %hhd\nDOMAIN (CURRENCY CODE): %s"),
			AdValue.ValueMicros, AdValue.PrecisionType, *AdValue.CurrencyCode));
	});
	InterstitialAd->OnDismissed.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD DISMISSED"));
		CleanUpInterstitialAds();
	});
	InterstitialAd->OnFailedToShow.AddLambda([this](const FGoogleAdMobAdError& AdError)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD FAILED TO SHOW WITH ERROR:\n") + AdError.FullError);
		CleanUpInterstitialAds();
	});
	InterstitialAd->OnShown.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD SHOWN"));
	});

	InterstitialAds.Add(InterstitialAd);

#if PLATFORM_ANDROID
	InterstitialAd->Load(TEXT("ca-app-pub-3940256099942544/1033173712"));
#elif PLATFORM_IOS
	InterstitialAd->Load(TEXT("ca-app-pub-3940256099942544/4411468910"));
#endif

	GoogleAdMobMenu->AddLogEntry(TEXT("LOADING INTERSTITIAL AD..."));
	GoogleAdMobMenu->UpdateInterstitialAdsNumber();
}

void UGoogleAdMobGameInstance::CleanUpInterstitialAds()
{
	InterstitialAds.RemoveAll([this](auto InterstitialAd)
	{
		if (InterstitialAd->GetState() == EGoogleAdMobAdState::Unknown
			|| InterstitialAd->GetState() == EGoogleAdMobAdState::Expired)
			return true;
		return false;
	});
	GoogleAdMobMenu->UpdateInterstitialAdsNumber();
}

void UGoogleAdMobGameInstance::IsInterstitialAdReady()
{
	for (auto InterstitialAd : InterstitialAds)
	{
		if (InterstitialAd->IsReady())
		{
			GoogleAdMobMenu->AddLogEntry(TEXT(
				"INTERSTITIAL AD IS READY TO BE SHOWN"));
			return;
		}
	}
	GoogleAdMobMenu->AddLogEntry(TEXT("INTERSTITIAL AD IS NOT LOADED OR HAS EXPIRED"));
}

void UGoogleAdMobGameInstance::ShowInterstitialAd()
{
	CleanUpInterstitialAds();
	for (auto InterstitialAd : InterstitialAds)
	{
		if (InterstitialAd->IsReady())
		{
			InterstitialAd->Show();
			return;
		}
	}
}

#pragma endregion

#pragma region REWARDED_AD

void UGoogleAdMobGameInstance::LoadRewardedAd()
{
#ifdef GOOGLE_UMP
	if (!UGoogleUMP::CanRequestAds())
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("UGoogleUMP::CanRequestAds() RETURNED FALSE. DID YOU OBTAIN CONSENT FROM THE USER?"));
		return;
	}
#endif

	UGoogleAdMobRewardedAd* RewardedAd = NewObject<UGoogleAdMobRewardedAd>();

	RewardedAd->OnLoaded.AddLambda([this](const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("REWARDED AD LOADED WITH RESPONSE INFO:\n") + ResponseInfo.FullResponse);
	});
	RewardedAd->OnFailedToLoad.AddLambda([this](const FGoogleAdMobAdError& LoadAdError,
		const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD FAILED TO LOAD WITH ERROR:\n") + LoadAdError.FullError +
			TEXT("\n...AND RESPONSE INFO:\n") + ResponseInfo.FullResponse);
		CleanUpRewardedAds();
	});
	RewardedAd->OnClicked.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD CLICKED"));
	});
	RewardedAd->OnImpression.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD IMPRESSION"));
	});
	RewardedAd->OnPaidEvent.AddLambda([this](const FGoogleAdMobAdValue& AdValue)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(TEXT(
			"REWARDED AD PAID WITH AD VALUE:\nVALUE MICROS: %lld\nPRECISION TYPE: %hhd\nDOMAIN (CURRENCY CODE): %s"),
			AdValue.ValueMicros, AdValue.PrecisionType, *AdValue.CurrencyCode));
	});
	RewardedAd->OnDismissed.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD DISMISSED"));
		CleanUpRewardedAds();
	});
	RewardedAd->OnFailedToShow.AddLambda([this](const FGoogleAdMobAdError& AdError)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD FAILED TO SHOW WITH ERROR:\n") + AdError.FullError);
		CleanUpRewardedAds();
	});
	RewardedAd->OnShown.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD SHOWN"));
	});
	RewardedAd->OnUserEarnedReward.AddLambda([this](int32 RewardAmount, const FString& RewardType)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(
			TEXT("USER EARNED REWARD: %i %s"), RewardAmount, *RewardType));
	});

	RewardedAds.Add(RewardedAd);

#if PLATFORM_ANDROID
	RewardedAd->Load(TEXT("ca-app-pub-3940256099942544/5224354917"));
#elif PLATFORM_IOS
	RewardedAd->Load(TEXT("ca-app-pub-3940256099942544/1712485313"));
#endif

	GoogleAdMobMenu->AddLogEntry(TEXT("LOADING REWARDED AD..."));
	GoogleAdMobMenu->UpdateRewardedAdsNumber();
}

void UGoogleAdMobGameInstance::CleanUpRewardedAds()
{
	RewardedAds.RemoveAll([this](auto RewardedAd)
	{
		if (RewardedAd->GetState() == EGoogleAdMobAdState::Unknown
			|| RewardedAd->GetState() == EGoogleAdMobAdState::Expired)
			return true;
		return false;
	});
	GoogleAdMobMenu->UpdateRewardedAdsNumber();
}

void UGoogleAdMobGameInstance::IsRewardedAdReady()
{
	for (auto RewardedAd : RewardedAds)
	{
		if (RewardedAd->IsReady())
		{
			GoogleAdMobMenu->AddLogEntry(TEXT(
				"REWARDED AD IS READY TO BE SHOWN"));
			return;
		}
	}
	GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED AD IS NOT LOADED OR HAS EXPIRED"));
}

void UGoogleAdMobGameInstance::ShowRewardedAd()
{
	CleanUpRewardedAds();
	for (auto RewardedAd : RewardedAds)
	{
		if (RewardedAd->GetState() == EGoogleAdMobAdState::Loaded)
		{
			RewardedAd->Show();
			return;
		}
	}
}

#pragma endregion

#pragma region REWARDED_INTERSTITIAL_AD

void UGoogleAdMobGameInstance::LoadRewardedInterstitialAd()
{
#ifdef GOOGLE_UMP
	if (!UGoogleUMP::CanRequestAds())
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("UGoogleUMP::CanRequestAds() RETURNED FALSE. DID YOU OBTAIN CONSENT FROM THE USER?"));
		return;
	}
#endif

	UGoogleAdMobRewardedInterstitialAd* RewardedInterstitialAd = NewObject<UGoogleAdMobRewardedInterstitialAd>();

	RewardedInterstitialAd->OnLoaded.AddLambda([this](const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(
			TEXT("REWARDED INTERSTITIAL AD LOADED WITH RESPONSE INFO:\n") + ResponseInfo.FullResponse);
	});
	RewardedInterstitialAd->OnFailedToLoad.AddLambda([this](const FGoogleAdMobAdError& LoadAdError,
		const FGoogleAdMobResponseInfo& ResponseInfo)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD FAILED TO LOAD WITH ERROR:\n") + LoadAdError.FullError +
			TEXT("\n...AND RESPONSE INFO:\n") + ResponseInfo.FullResponse);
		CleanUpRewardedInterstitialAds();
	});
	RewardedInterstitialAd->OnClicked.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD CLICKED"));
	});
	RewardedInterstitialAd->OnImpression.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD IMPRESSION"));
	});
	RewardedInterstitialAd->OnPaidEvent.AddLambda([this](const FGoogleAdMobAdValue& AdValue)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(TEXT(
			"REWARDED INTERSTITIAL AD PAID WITH AD VALUE:\nVALUE MICROS: %lld\nPRECISION TYPE: %hhd\nDOMAIN (CURRENCY CODE): %s"),
			AdValue.ValueMicros, AdValue.PrecisionType, *AdValue.CurrencyCode));
	});
	RewardedInterstitialAd->OnDismissed.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD DISMISSED"));
		CleanUpRewardedInterstitialAds();
	});
	RewardedInterstitialAd->OnFailedToShow.AddLambda([this](const FGoogleAdMobAdError& AdError)
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD FAILED TO SHOW WITH ERROR:\n") + AdError.FullError);
		CleanUpRewardedInterstitialAds();
	});
	RewardedInterstitialAd->OnShown.AddLambda([this]()
	{
		GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD SHOWN"));
	});
	RewardedInterstitialAd->OnUserEarnedReward.AddLambda([this](int32 RewardAmount, const FString& RewardType)
	{
		GoogleAdMobMenu->AddLogEntry(FString::Printf(
			TEXT("USER EARNED INTERSTITIAL REWARD: %i %s"), RewardAmount, *RewardType));
	});

	RewardedInterstitialAds.Add(RewardedInterstitialAd);

#if PLATFORM_ANDROID
	RewardedInterstitialAd->Load(TEXT("ca-app-pub-3940256099942544/5354046379"));
#elif PLATFORM_IOS
	RewardedInterstitialAd->Load(TEXT("ca-app-pub-3940256099942544/6978759866"));
#endif

	GoogleAdMobMenu->AddLogEntry(TEXT("LOADING REWARDED INTERSTITIAL AD..."));
	GoogleAdMobMenu->UpdateRewardedInterstitialAdsNumber();
}

void UGoogleAdMobGameInstance::CleanUpRewardedInterstitialAds()
{
	RewardedInterstitialAds.RemoveAll([this](auto RewardedInterstitialAd)
	{
		if (RewardedInterstitialAd->GetState() == EGoogleAdMobAdState::Unknown
			|| RewardedInterstitialAd->GetState() == EGoogleAdMobAdState::Expired)
			return true;
		return false;
	});
	GoogleAdMobMenu->UpdateRewardedInterstitialAdsNumber();
}

void UGoogleAdMobGameInstance::IsRewardedInterstitialAdReady()
{
	for (auto RewardedInterstitialAd : RewardedInterstitialAds)
	{
		if (RewardedInterstitialAd->IsReady())
		{
			GoogleAdMobMenu->AddLogEntry(TEXT(
				"REWARDED INTERSTITIAL AD IS READY TO BE SHOWN"));
			return;
		}
	}
	GoogleAdMobMenu->AddLogEntry(TEXT("REWARDED INTERSTITIAL AD IS NOT LOADED OR HAS EXPIRED"));
}

void UGoogleAdMobGameInstance::ShowRewardedInterstitialAd()
{
	CleanUpRewardedInterstitialAds();
	for (auto RewardedInterstitialAd : RewardedInterstitialAds)
	{
		if (RewardedInterstitialAd->IsReady())
		{
			RewardedInterstitialAd->Show();
			return;
		}
	}
}

#pragma endregion
