// Copyright 2025 Władysław Witkowski. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintPlatformLibrary.h"
#include "GoogleAdMobGameInstance.generated.h"

class UGoogleAdMobRewardedInterstitialAd;
class UGoogleAdMobRewardedAd;
class UGoogleAdMobInterstitialAd;
enum class EGoogleAdMobBannerPosition : uint8;
struct FGoogleAdMobAdError;
struct FGoogleAdMobAdValue;
class UGoogleAdMobMenu;
class UGoogleAdMobAppOpenAd;
struct FGoogleAdMobResponseInfo;
class UGoogleAdMobBannerAd;
enum class EGoogleAdMobBannerSize: uint8;
enum class EGoogleAdMobCollapsibleBannerPlacement: uint8;

UCLASS()
class GOOGLEADMOBCPP_API UGoogleAdMobGameInstance : public UPlatformGameInstance
{
	GENERATED_BODY()

	friend class UGoogleAdMobMenu;
	
	virtual void Init() override;
	virtual void OnStart() override;

	UPROPERTY()
	TObjectPtr<UGoogleAdMobMenu> GoogleAdMobMenu;

	UPROPERTY()
	TArray<TObjectPtr<UGoogleAdMobAppOpenAd>> AppOpenAds;

	void LoadAppOpenAd();
	void CleanUpAppOpenAds();
	void IsAppOpenAdReady();
	UFUNCTION() void ShowAppOpenAd();

	UPROPERTY()
	TObjectPtr<UGoogleAdMobBannerAd> BannerAd;

	void LoadBannerAd(EGoogleAdMobBannerSize BannerSize, EGoogleAdMobCollapsibleBannerPlacement CollapsibleBannerPlacement) const;
	void ShowBannerAd(EGoogleAdMobBannerPosition BannerPosition) const;
	void HideBannerAd() const;
	void DestroyBannerAd() const;
	void BannerAdLoaded(const FGoogleAdMobResponseInfo& ResponseInfo) const;
	void BannerAdFailedToLoad(const FGoogleAdMobAdError& LoadAdError, const FGoogleAdMobResponseInfo& ResponseInfo) const;
	void BannerAdClicked() const;
	void BannerAdImpression() const;
	void BannerAdOpened() const;
	void BannerAdPaidEvent(const FGoogleAdMobAdValue& AdValue) const;

	UPROPERTY()
	TArray<TObjectPtr<UGoogleAdMobInterstitialAd>> InterstitialAds;

	void LoadInterstitialAd();
	void CleanUpInterstitialAds();
	void IsInterstitialAdReady();
	void ShowInterstitialAd();

	UPROPERTY()
	TArray<TObjectPtr<UGoogleAdMobRewardedAd>> RewardedAds;

	void LoadRewardedAd();
	void CleanUpRewardedAds();
	void IsRewardedAdReady();
	void ShowRewardedAd();

	UPROPERTY()
	TArray<TObjectPtr<UGoogleAdMobRewardedInterstitialAd>> RewardedInterstitialAds;

	void LoadRewardedInterstitialAd();
	void CleanUpRewardedInterstitialAds();
	void IsRewardedInterstitialAdReady();
	void ShowRewardedInterstitialAd();
};
