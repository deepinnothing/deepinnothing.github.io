// Copyright Epic Games, Inc. All Rights Reserved.

using System.IO;
using System.Linq;
using EpicGames.Core;
using UnrealBuildTool;

public class GoogleAdMobCPP : ModuleRules
{
	public GoogleAdMobCPP(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
	
		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "EnhancedInput" });

		PrivateDependencyModuleNames.AddRange(new string[] { "GoogleAdMob", "SlateCore" });
		var googleUmpPlugin = Plugins.GetPlugin("GoogleUMP");
		if (googleUmpPlugin != null)
		{
			bool googleUmpEnabled = Plugins.IsPluginEnabledForTarget(googleUmpPlugin, 
					ProjectDescriptor.FromFile(Target.ProjectFile!), Target.Platform, Target.Configuration, Target.Type);
			if (googleUmpEnabled)
			{
				PrivateDependencyModuleNames.Add("GoogleUMP");
				PrivateDefinitions.Add("GOOGLE_UMP=1");
			}
		}

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });
		
		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
